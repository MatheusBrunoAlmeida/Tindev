# Backend do Tindev

Para que o backend funcione, é necessário executar:

1 - `$ cp .env.example .env`

2- Altere o valor de `DB_URI` no arquivo `.env` para a URL do seu banco mongobd 